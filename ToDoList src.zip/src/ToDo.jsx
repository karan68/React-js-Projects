import React, { useState } from 'react';
import './index.css';
import ToDoList from './ToDoList';
const ToDo =() =>{
    
    const[item,setItem] = useState("");
    const [newItem,setNewItems] = useState([]);
    const inputEvent = (event) => {
        setItem(event.target.value)
   };
   const Submits = () =>{
    
    setNewItems((oldItems) =>{
        return [...oldItems, item];
    });
    setItem("");
   };

    const deleteItems = (id) => {
        
        setNewItems((oldItems) => {
            return oldItems.filter((arrElem,index) => {
                return index !==id;
            });
        });
        }

  




    return(
        <>
            <div className ="main_div">
                <div className ="center_div">
           
                    <br />
                    <h1> ToDo List</h1>
                
                <input type="text" placeholder ="Add a Item"
                onChange={inputEvent} value={item} />
                <button onClick={Submits}> + </button>
                

                {newItem.map( (itemval,index) => {
                    return(
                         <ToDoList 
                         key={index}
                         id={index}
                         onSelect={deleteItems}
                         text={itemval}
                         />
                    );
                } )}
               
                </div>
            </div>

        </>
    )
};
export default ToDo;